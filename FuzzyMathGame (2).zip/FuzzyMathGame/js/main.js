"use strict";

/* =====================================================
   FuzzyMathGame - main.js

   完整版本：
   1. 保留原有遊戲功能
   2. 題目與解題過程分開顯示
   3. 中間計算結果直接顯示
   4. 最終答案使用輸入欄填寫
   5. 使用實體鍵盤輸入數學表達式
   6. 特殊符號工具列支援游標位置插入
   7. 保留 Flask API、提示、計時與判分
   ===================================================== */


// =====================================================
// 1. 遊戲設定
// =====================================================

const API_BASE = "";

const INITIAL_HP = 100;
const INITIAL_MP = 100;
const INITIAL_EXP = 50;

const MAX_EXP = 100;
const PASS_EXP = 80;

const QUESTION_TIME = 90;
const HP_LOSS = 20;
const MP_RECOVERY = 15;
const HINT_MP_COST = 20;

const LEVEL_TYPE_IDS = {
    1: Array.from(
        { length: 20 },
        (_, index) => `F${String(index + 1).padStart(2, "0")}`
    ),
    2: [],
    3: [],
    4: [],
    5: [],
    6: [],
    7: [],
    8: []
};

const LEVEL_NAMES = {
    1: "函數與數學基礎",
    2: "極限與連續",
    3: "微分的基本概念",
    4: "微分法則",
    5: "微分的應用",
    6: "不定積分",
    7: "定積分",
    8: "積分的應用"
};


// =====================================================
// 2. 遊戲狀態
// =====================================================

let currentLevel = 1;
let currentTypeId = null;
let currentQuestion = null;

let currentHP = INITIAL_HP;
let currentMP = INITIAL_MP;
let currentEXP = INITIAL_EXP;

let remainingTime = QUESTION_TIME;
let timerId = null;
let nextQuestionTimeoutId = null;

let loadingQuestion = false;
let gameFinished = false;
let hintUsed = false;

let selectedBlankId = null;

let blankAnswers = {};
let blankExpectedAnswers = {};
let blankHints = {};

let questionRequestId = 0;


// 輸入欄游標位置
let savedInputSelectionStart = 0;
let savedInputSelectionEnd = 0;


// =====================================================
// 3. DOM 工具
// =====================================================

function getElement(id) {
    return document.getElementById(id);
}

function showPage(pageId) {
    document.querySelectorAll(".app-shell > .page").forEach(page => {
        page.classList.toggle("hidden", page.id !== pageId);
    });
}

function showHomePage() {
    leaveGame();
    showPage("home-page");
}

function showLevelPage() {
    leaveGame();
    showPage("level-page");
}

function leaveGame() {
    questionRequestId++;

    stopTimer();
    clearNextQuestionTimeout();

    loadingQuestion = false;
    gameFinished = false;
}

function clearNextQuestionTimeout() {
    if (nextQuestionTimeoutId !== null) {
        window.clearTimeout(nextQuestionTimeoutId);
        nextQuestionTimeoutId = null;
    }
}


// =====================================================
// 4. 回饋訊息
// =====================================================

function showFeedback(message, type = "info") {
    const element = getElement("feedback-message");

    if (!element) return;

    element.textContent = message;
    element.dataset.type = type;

    element.classList.remove("success", "error");

    if (type === "success") {
        element.classList.add("success");
    } else if (type === "error") {
        element.classList.add("error");
    }
}

function clearFeedback() {
    showFeedback("");
}


// =====================================================
// 5. 更新玩家狀態
// =====================================================

function updateStatus() {
    const hpValue = getElement("hp-value");
    const mpValue = getElement("mp-value");
    const expValue = getElement("exp-value");
    const timer = getElement("timer");

    if (hpValue) hpValue.textContent = currentHP;
    if (mpValue) mpValue.textContent = currentMP;
    if (expValue) expValue.textContent = currentEXP;
    if (timer) timer.textContent = remainingTime;

    const hpBar = getElement("hp-bar");
    const mpBar = getElement("mp-bar");
    const expBar = getElement("exp-bar");

    if (hpBar) {
        hpBar.style.width =
            `${Math.max(0, Math.min(100, currentHP / INITIAL_HP * 100))}%`;
    }

    if (mpBar) {
        mpBar.style.width =
            `${Math.max(0, Math.min(100, currentMP / INITIAL_MP * 100))}%`;
    }

    if (expBar) {
        expBar.style.width =
            `${Math.max(0, Math.min(100, currentEXP / MAX_EXP * 100))}%`;
    }
}


// =====================================================
// 6. 數學公式處理
// =====================================================

function normalizeMathSigns(value) {
    if (value === null || value === undefined) return "";

    let text = String(value).trim();

    if (!text) return "";

    text = text.replace(/−/g, "-");
    text = text.replace(/\+\s*-/g, "-");
    text = text.replace(/-\s*-/g, "+");
    text = text.replace(/-\s*\+/g, "-");
    text = text.replace(/\+\s*\+/g, "+");

    return text;
}

function normalizeLatex(value) {
    let text = normalizeMathSigns(value);

    if (!text) return "";

    if (
        text.startsWith("\\(") ||
        text.startsWith("\\[") ||
        text.startsWith("$$") ||
        text.startsWith("$")
    ) {
        return text;
    }

    text = text.replace(
        /\bsqrt\s*\(([^()]*)\)/g,
        (_, inside) => `\\sqrt{${inside}}`
    );

    return `\\(${text}\\)`;
}

function appendMath(parent, latex) {
    const element = document.createElement("span");

    element.className = "math-content";
    element.textContent = normalizeLatex(latex);

    parent.appendChild(element);

    return element;
}

function renderMath(element) {
    if (!element) return;

    if (typeof window.renderMathInElement !== "function") {
        console.warn(
            "KaTeX auto-render 尚未載入，請檢查 HTML 中的 KaTeX script。"
        );
        return;
    }

    window.renderMathInElement(element, {
        delimiters: [
            { left: "$$", right: "$$", display: true },
            { left: "\\[", right: "\\]", display: true },
            { left: "\\(", right: "\\)", display: false },
            { left: "$", right: "$", display: false }
        ],
        throwOnError: false,
        strict: "ignore"
    });
}


// =====================================================
// 7. 開始遊戲
// =====================================================

async function startGame(level) {
    const selectedLevel = Number(level);
    const availableTypes = LEVEL_TYPE_IDS[selectedLevel] || [];

    if (availableTypes.length === 0) {
        alert("這個章節目前尚未開放題目。");
        return;
    }

    leaveGame();

    currentLevel = selectedLevel;

    currentTypeId = availableTypes[
        Math.floor(Math.random() * availableTypes.length)
    ];

    currentQuestion = null;

    currentHP = INITIAL_HP;
    currentMP = INITIAL_MP;
    currentEXP = INITIAL_EXP;

    remainingTime = QUESTION_TIME;

    gameFinished = false;
    loadingQuestion = false;
    hintUsed = false;

    blankAnswers = {};
    blankExpectedAnswers = {};
    blankHints = {};

    selectedBlankId = null;

    const chapterLabel = getElement("chapter-label");
    const questionBox = getElement("question-box");
    const difficulty = getElement("question-difficulty");
    const processBox = getElement("process-box");

    if (chapterLabel) {
        chapterLabel.textContent =
            `CHAPTER ${String(currentLevel).padStart(2, "0")}`;
    }

    if (questionBox) {
        questionBox.textContent = "正在載入題目……";
    }

    if (difficulty) {
        difficulty.textContent = "難度：載入中";
    }

    if (processBox) {
        processBox.replaceChildren();
    }

    clearInputField();
    updateSelectedBlankLabel();

    clearFeedback();
    updateStatus();

    showPage("game-page");

    await loadNextQuestion();
}


// =====================================================
// 8. 載入下一題
// =====================================================

async function loadNextQuestion() {
    if (
        loadingQuestion ||
        !currentTypeId ||
        gameFinished
    ) {
        return;
    }

    loadingQuestion = true;

    stopTimer();
    clearNextQuestionTimeout();

    const requestId = ++questionRequestId;

    const questionBox = getElement("question-box");
    const difficulty = getElement("question-difficulty");
    const processBox = getElement("process-box");

    if (questionBox) {
        questionBox.textContent = "正在載入題目……";
    }

    if (difficulty) {
        difficulty.textContent = "難度：載入中";
    }

    if (processBox) {
        processBox.replaceChildren();
    }

    selectedBlankId = null;

    blankAnswers = {};
    blankExpectedAnswers = {};
    blankHints = {};

    clearInputField();
    updateSelectedBlankLabel();

    try {
        const url =
            `${API_BASE}/api/questions/generate-with-steps/` +
            `${encodeURIComponent(currentTypeId)}?difficulty=1`;

        const response = await fetch(url);
        const rawText = await response.text();

        let data;

        try {
            data = JSON.parse(rawText);
        } catch {
            throw new Error(
                `後端沒有回傳有效 JSON：${rawText.slice(0, 150)}`
            );
        }

        if (!response.ok) {
            throw new Error(
                data.error ||
                data.message ||
                `HTTP ${response.status}`
            );
        }

        if (data.status && data.status !== "success") {
            throw new Error(
                data.message ||
                data.error ||
                "後端未成功產生題目。"
            );
        }

        if (requestId !== questionRequestId) {
            return;
        }

        currentQuestion = data;

        hintUsed = false;

        renderQuestion(data);

        renderProcess(
            data.steps ||
            data["步驟"] ||
            []
        );

        remainingTime = QUESTION_TIME;

        updateStatus();
        clearFeedback();

        startTimer();

        console.log("後端題目資料：", data);

    } catch (error) {
        console.error("載入題目失敗：", error);

        if (requestId === questionRequestId) {
            showFeedback(
                `載入題目失敗：${error.message}`,
                "error"
            );

            if (questionBox) {
                questionBox.textContent =
                    "題目載入失敗，請確認 Flask 後端與 API 是否正常。";
            }
        }

    } finally {
        if (requestId === questionRequestId) {
            loadingQuestion = false;
        }
    }
}


// =====================================================
// 9. 顯示題目
// =====================================================

function renderQuestion(data) {
    const questionBox = getElement("question-box");
    const difficultyLabel = getElement("question-difficulty");

    if (!questionBox || !difficultyLabel) return;

    questionBox.replaceChildren();

    const questionText = String(
        data.question_text || ""
    ).trim();

    function toLatex(expression) {
        let text = expression.trim();

        text = text.replace(
            /sqrt\s*\(([^()]*)\)/gi,
            (_, inside) => {
                const inner = inside
                    .replace(/\^([+-]?\d+)/g, "^{$1}")
                    .replace(/\*/g, "\\times ")
                    .replace(/×/g, "\\times ")
                    .replace(/÷/g, "\\div ");

                return `\\sqrt{${inner}}`;
            }
        );

        text = text.replace(
            /\^\s*([+-]?\d+)/g,
            "^{$1}"
        );

        text = text.replace(/\*/g, "\\times ");
        text = text.replace(/×/g, "\\times ");
        text = text.replace(/÷/g, "\\div ");
        text = text.replace(/\s*=\s*/g, " = ");

        return text;
    }

    function renderQuestionText(text) {
        const fragment = document.createDocumentFragment();

        const pattern =
            /(?:[fgh]\s*\(\s*[a-zA-Z]\s*\)\s*=\s*[^，。、；;]+)|(?:[fgh]\s*\(\s*[fgh]\s*\(\s*[a-zA-Z]\s*\)\s*\))|(?:sqrt\s*\([^()]*\))|(?:[a-zA-Z0-9]+\s*(?:\^\s*[+-]?\d+)?\s*(?:[+\-*/×÷]\s*[a-zA-Z0-9]+\s*(?:\^\s*[+-]?\d+)?)*\s*=\s*[-+]?\d+(?:\.\d+)?)/g;

        let lastIndex = 0;
        let match;

        while ((match = pattern.exec(text)) !== null) {
            if (match.index > lastIndex) {
                fragment.appendChild(
                    document.createTextNode(
                        text.slice(lastIndex, match.index)
                    )
                );
            }

            const math = document.createElement("span");

            math.className = "math-content";
            math.textContent =
                `\\(${toLatex(match[0].trim())}\\)`;

            fragment.appendChild(math);

            lastIndex = pattern.lastIndex;
        }

        if (lastIndex < text.length) {
            fragment.appendChild(
                document.createTextNode(text.slice(lastIndex))
            );
        }

        return fragment;
    }

    if (questionText) {
        const description = document.createElement("div");

        description.className = "question-description";
        description.appendChild(
            renderQuestionText(questionText)
        );

        questionBox.appendChild(description);

    } else if (data.question_latex) {
        const formula = document.createElement("div");

        formula.className = "question-expression";

        appendMath(formula, data.question_latex);

        questionBox.appendChild(formula);

    } else {
        questionBox.textContent = "後端沒有提供題目內容。";
    }

    difficultyLabel.textContent =
        `難度：${data.difficulty ?? "未知"}`;

    renderMath(questionBox);
}


// =====================================================
// 10. 建立最終答案空格
// =====================================================

function makeBlankId(blankData) {
    if (
        blankData.blank_id !== undefined &&
        blankData.blank_id !== null
    ) {
        return `blank_${blankData.blank_id}`;
    }

    return `blank_${blankData.blank_key || blankData.step_order}`;
}

function createAnswerBlank(blankId, order) {
    const blank = document.createElement("button");

    blank.type = "button";
    blank.className = "answer-blank";

    blank.dataset.blankId = blankId;
    blank.dataset.stepOrder = String(order);

    blank.textContent =
        blankAnswers[blankId] || "點此填入最終答案";

    blank.setAttribute(
        "aria-label",
        `選取第 ${order} 步的最終答案`
    );

    blank.addEventListener("click", () => {
        selectBlank(blankId);
    });

    return blank;
}

function selectBlank(blankId) {
    if (!Object.prototype.hasOwnProperty.call(
        blankExpectedAnswers,
        blankId
    )) {
        showFeedback("這個空格不是可填寫的答案欄位。", "error");
        return;
    }

    selectedBlankId = blankId;

    const input = getElement("math-input");

    if (input) {
        input.value = blankAnswers[blankId] || "";
        input.focus();

        const end = input.value.length;
        input.setSelectionRange(end, end);

        saveInputSelection();
    }

    updateSelectedBlank();
    updateSelectedBlankLabel();

    showFeedback("已選取答案空格，可以直接輸入數學表達式。");
}

function updateSelectedBlank() {
    document.querySelectorAll(".answer-blank, .blank-slot").forEach(blank => {
        blank.classList.toggle(
            "selected",
            blank.dataset.blankId === selectedBlankId
        );
    });
}

function updateSelectedBlankLabel() {
    const label = getElement("selected-blank-label");

    if (!label) return;

    if (!selectedBlankId) {
        label.textContent = "尚未選取空格";
        return;
    }

    const blank = Array.from(
        document.querySelectorAll(".answer-blank")
    ).find(element => element.dataset.blankId === selectedBlankId);

    const order = blank?.dataset.stepOrder;

    label.textContent = order
        ? `第 ${order} 步：最終答案`
        : "最終答案";
}


// =====================================================
// 11. 解題步驟與公式
// =====================================================

function appendStepLatexWithBlanks(parent, latex, blanksForStep) {
    const text = String(latex || "");

    const markerPattern =
        /\{\{\s*blank:([A-Za-z_][A-Za-z0-9_]*)\s*\}\}/g;

    let lastIndex = 0;
    let match;

    while ((match = markerPattern.exec(text)) !== null) {
        const precedingText = text.slice(
            lastIndex,
            match.index
        );

        if (precedingText) {
            appendMath(parent, precedingText);
        }

        const blankKey = match[1];

        if (blankKey === "answer") {
            const blankData = blanksForStep.find(
                item => String(item.blank_key) === "answer"
            );

            if (blankData) {
                const blankId = makeBlankId(blankData);

                blankExpectedAnswers[blankId] =
                    blankData.correct_answer_template ?? "";

                blankHints[blankId] =
                    blankData.hint || "";

                parent.appendChild(
                    createAnswerBlank(
                        blankId,
                        blankData.step_order
                    )
                );

            } else {
                appendMath(parent, "?");

                console.warn(
                    "最終答案標記找不到對應的 blank_rule。"
                );
            }

        } else {
            appendMath(parent, "?");
        }

        lastIndex = markerPattern.lastIndex;
    }

    const remainingText = text.slice(lastIndex);

    if (remainingText) {
        appendMath(parent, remainingText);
    }
}

function renderProcess(steps) {
    const processBox = getElement("process-box");

    if (!processBox) return;

    processBox.replaceChildren();

    if (!Array.isArray(steps) || steps.length === 0) {
        const empty = document.createElement("p");

        empty.className = "empty-message";
        empty.textContent =
            "後端目前沒有提供可顯示的解題步驟。";

        processBox.appendChild(empty);
        return;
    }

    const allBlanks = (
        currentQuestion?.blanks ||
        currentQuestion?.["空白處"] ||
        []
    );

    steps.forEach((step, index) => {
        const order = Number(
            step.step_order || index + 1
        );

        let content = String(
            step.step_latex_template ||
            step.step_template ||
            step.content ||
            ""
        );

        /*
         * 中間計算結果直接顯示。
         * 只有 answer 標記保留成可填寫空格。
         */
        content = content.replace(
            /\{\{\s*blank:([A-Za-z_][A-Za-z0-9_]*)\s*\}\}/g,
            (marker, key) => {
                if (key === "answer") {
                    return marker;
                }

                const rule = allBlanks.find(
                    item =>
                        String(item.blank_key) === key &&
                        Number(item.step_order) === order
                );

                if (
                    rule &&
                    rule.correct_answer_template != null
                ) {
                    return String(
                        rule.correct_answer_template
                    );
                }

                return "?";
            }
        );

        const row = document.createElement("div");

        row.className = "process-step";
        row.dataset.stepOrder = String(order);

        const description = document.createElement("div");

        description.className = "step-description";
        description.textContent =
            step.step_description || `步驟 ${order}`;

        const equation = document.createElement("div");

        equation.className = "step-equation";

        row.appendChild(description);
        row.appendChild(equation);

        const answerBlanks = allBlanks.filter(
            item =>
                String(item.blank_key) === "answer" &&
                Number(item.step_order) === order
        );

        if (
            /\{\{\s*blank:answer\s*\}\}/.test(content) &&
            answerBlanks.length > 0
        ) {
            appendStepLatexWithBlanks(
                equation,
                content,
                answerBlanks
            );
        } else {
            appendMath(equation, content);
        }

        processBox.appendChild(row);
    });

    renderMath(processBox);

    updateSelectedBlank();
    updateSelectedBlankLabel();
}


// =====================================================
// 12. 新版輸入欄
// =====================================================

function getMathInput() {
    return getElement("math-input");
}

function clearInputField() {
    const input = getMathInput();

    if (input) {
        input.value = "";
    }

    savedInputSelectionStart = 0;
    savedInputSelectionEnd = 0;
}

function saveInputSelection() {
    const input = getMathInput();

    if (!input) return;

    savedInputSelectionStart =
        input.selectionStart ?? input.value.length;

    savedInputSelectionEnd =
        input.selectionEnd ?? input.value.length;
}

function syncInputToAnswer() {
    const input = getMathInput();

    if (!input || !selectedBlankId) return;

    blankAnswers[selectedBlankId] = input.value;

    updateBlankText(selectedBlankId);
}

function updateBlankText(blankId) {
    const blank = Array.from(
        document.querySelectorAll(".answer-blank")
    ).find(element => element.dataset.blankId === blankId);

    if (!blank) return;

    const value = blankAnswers[blankId] || "";

    blank.replaceChildren();

    if (!value) {
        blank.textContent = "點此填入最終答案";
        return;
    }

    /*
     * 使用文字節點，避免玩家輸入的內容被當成 HTML。
     */
    blank.textContent = value;
}

function handleMathInput() {
    if (!selectedBlankId) {
        showFeedback("請先點選解題過程中的最終答案空格。");
        return;
    }

    const input = getMathInput();

    if (!input) return;

    blankAnswers[selectedBlankId] = input.value;

    updateBlankText(selectedBlankId);
    saveInputSelection();
}

function insertAtCursor(text) {
    const input = getMathInput();

    if (!input) return;

    if (!selectedBlankId) {
        showFeedback("請先點選最終答案空格。");
        return;
    }

    const value = input.value;

    const start = input.selectionStart ?? value.length;
    const end = input.selectionEnd ?? value.length;

    input.value =
        value.slice(0, start) +
        text +
        value.slice(end);

    const cursorPosition = start + text.length;

    input.focus();

    input.setSelectionRange(
        cursorPosition,
        cursorPosition
    );

    syncInputToAnswer();
    saveInputSelection();
}

function insertMathSymbol(symbol) {
    const input = getMathInput();

    if (!input) return;

    if (!selectedBlankId) {
        showFeedback("請先選擇解題過程中的最終答案空格。");
        return;
    }

    insertAtCursor(symbol);
}

function backspaceMath() {
    const input = getMathInput();

    if (!input || !selectedBlankId) {
        showFeedback("請先選擇最終答案空格。");
        return;
    }

    const value = input.value;

    let start = input.selectionStart ?? value.length;
    let end = input.selectionEnd ?? value.length;

    if (start === end && start > 0) {
        start--;
    }

    input.value =
        value.slice(0, start) +
        value.slice(end);

    input.focus();

    input.setSelectionRange(start, start);

    syncInputToAnswer();
    saveInputSelection();
}

function clearSelectedBlank() {
    const input = getMathInput();

    if (!selectedBlankId || !input) {
        showFeedback("請先選擇最終答案空格。");
        return;
    }

    input.value = "";

    blankAnswers[selectedBlankId] = "";

    input.focus();
    input.setSelectionRange(0, 0);

    updateBlankText(selectedBlankId);
    saveInputSelection();

    showFeedback("已清空目前選取的答案空格。");
}

function confirmBlank() {
    if (!selectedBlankId) {
        showFeedback("請先選擇最終答案空格。");
        return;
    }

    syncInputToAnswer();

    const answer = (
        blankAnswers[selectedBlankId] || ""
    ).trim();

    if (!answer) {
        showFeedback("目前答案是空的，請先輸入內容。", "error");
        return;
    }

    showFeedback("答案已保存，可以繼續作答或提交。", "success");
}


// =====================================================
// 13. 特殊符號工具列初始化
// =====================================================

function initializeSymbolToolbar() {
    const toolbar = getElement("math-symbols");

    if (!toolbar) {
        console.warn("找不到 math-symbols，請檢查 HTML。");
        return;
    }

    toolbar.querySelectorAll("[data-symbol]").forEach(button => {
        button.addEventListener("mousedown", event => {
            /*
             * 避免滑鼠點擊符號按鈕時，
             * 輸入欄失去游標位置。
             */
            event.preventDefault();
            saveInputSelection();
        });

        button.addEventListener("click", () => {
            const symbol = button.dataset.symbol;

            if (symbol) {
                insertMathSymbol(symbol);
            }
        });
    });
}


// =====================================================
// 14. 答案比對
// =====================================================

function normalizeAnswer(value) {
    return String(value || "")
        .trim()
        .replace(/\s+/g, "")
        .replace(/\\left|\\right/g, "")
        .replace(/\\,/g, "")
        .replace(/\\;/g, "")
        .replace(/\\!/g, "")
        .replace(/\\cdot/g, "*")
        .replace(/\\times/g, "*")
        .replace(/×/g, "*")
        .replace(/\\div/g, "/")
        .replace(/÷/g, "/")
        .replace(/−/g, "-")
        .replace(/[{}]/g, "");
}

function checkAnswer() {
    if (!currentQuestion) {
        showFeedback("目前沒有題目可以作答。", "error");
        return;
    }

    if (gameFinished || loadingQuestion) {
        showFeedback("目前正在處理題目，請稍候。");
        return;
    }

    syncInputToAnswer();

    const ids = Object.keys(blankExpectedAnswers);

    if (ids.length === 0) {
        showFeedback(
            "目前沒有最終答案空格，請確認後端有設定 answer 挖空規則。",
            "error"
        );
        return;
    }

    const unanswered = ids.filter(
        id => !(blankAnswers[id] || "").trim()
    );

    if (unanswered.length > 0) {
        showFeedback("請先填寫最終答案。", "error");
        return;
    }

    const incorrect = ids.filter(id => {
        return (
            normalizeAnswer(blankAnswers[id]) !==
            normalizeAnswer(blankExpectedAnswers[id])
        );
    });

    if (incorrect.length > 0) {
        currentHP = Math.max(0, currentHP - HP_LOSS);

        updateStatus();

        showFeedback(
            "答案不正確，請重新檢查後再提交。",
            "error"
        );

        if (currentHP <= 0) {
            finishGame("HP 歸零，冒險結束。");
        }

        return;
    }

    currentEXP = Math.min(MAX_EXP, currentEXP + 3);

    currentMP = Math.min(
        INITIAL_MP,
        currentMP + MP_RECOVERY
    );

    updateStatus();

    if (currentEXP >= PASS_EXP) {
        finishGame("恭喜！你已達到本次冒險的 EXP 通過門檻。");
        return;
    }

    showFeedback(
        "答案正確！EXP 增加，MP 已恢復。",
        "success"
    );

    nextQuestionTimeoutId = window.setTimeout(() => {
        nextQuestionTimeoutId = null;

        if (!gameFinished) {
            loadNextQuestion();
        }
    }, 1200);
}


// =====================================================
// 15. 遊戲結束
// =====================================================

function finishGame(message) {
    gameFinished = true;

    stopTimer();
    clearNextQuestionTimeout();

    showFeedback(message, "success");
}


// =====================================================
// 16. 提示功能
// =====================================================

function useHint() {
    if (!currentQuestion) {
        showFeedback("請先載入題目。");
        return;
    }

    if (!selectedBlankId) {
        showFeedback("請先選擇最終答案空格。");
        return;
    }

    if (currentMP < HINT_MP_COST) {
        showFeedback("MP 不足，無法使用提示。", "error");
        return;
    }

    const hint = blankHints[selectedBlankId];

    if (!hint) {
        showFeedback("這個答案目前沒有可用的提示。");
        return;
    }

    currentMP -= HINT_MP_COST;
    hintUsed = true;

    updateStatus();

    showFeedback(`提示：${hint}`, "info");
}


// =====================================================
// 17. 倒數計時
// =====================================================

function startTimer() {
    stopTimer();

    timerId = window.setInterval(() => {
        if (gameFinished || !currentQuestion) {
            stopTimer();
            return;
        }

        remainingTime = Math.max(
            0,
            remainingTime - 1
        );

        updateStatus();

        if (remainingTime <= 0) {
            stopTimer();

            currentHP = Math.max(
                0,
                currentHP - HP_LOSS
            );

            updateStatus();

            if (currentHP <= 0) {
                finishGame("時間到且 HP 歸零，冒險結束。");
                return;
            }

            showFeedback("時間到！正在載入下一題。", "error");

            nextQuestionTimeoutId = window.setTimeout(() => {
                nextQuestionTimeoutId = null;

                if (!gameFinished) {
                    loadNextQuestion();
                }
            }, 500);
        }
    }, 1000);
}

function stopTimer() {
    if (timerId !== null) {
        window.clearInterval(timerId);
        timerId = null;
    }
}


// =====================================================
// 18. 初始化
// =====================================================

function initializeGame() {
    const input = getMathInput();

    if (input) {
        input.addEventListener("input", handleMathInput);

        input.addEventListener("click", saveInputSelection);
        input.addEventListener("keyup", saveInputSelection);
        input.addEventListener("select", saveInputSelection);

        input.addEventListener("keydown", event => {
            if (event.key === "Enter") {
                event.preventDefault();
                confirmBlank();
            }
        });

        input.addEventListener("blur", saveInputSelection);
    }

    initializeSymbolToolbar();

    updateStatus();
    updateSelectedBlankLabel();

    showPage("home-page");

    console.log("FuzzyMathGame main.js 已成功載入。");
}

document.addEventListener(
    "DOMContentLoaded",
    initializeGame
);