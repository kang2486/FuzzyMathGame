@echo off
chcp 65001 >nul

cd /d "%USERPROFILE%\Desktop\FuzzyMathGame\backend"

REM 設定 MySQL 資料庫密碼
set "FUZZY_DB_PASSWORD=Auag74123"

REM 開啟遊戲網頁
start "" http://127.0.0.1:5000/

REM 啟動 Flask 後端
python app.py

pause
