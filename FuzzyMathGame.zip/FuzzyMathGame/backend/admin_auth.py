"""Local administrator account and signed sessions; secrets never enter static files."""
from datetime import timedelta
from functools import wraps
import hmac
import json
import os
from pathlib import Path
import secrets
import time

from flask import current_app, jsonify, request, session
from werkzeug.security import generate_password_hash, check_password_hash


def configure_admin(app):
    directory = Path(app.root_path).parent / '.local'
    directory.mkdir(exist_ok=True)
    path = directory / 'admin-auth.json'
    if path.exists():
        account = json.loads(path.read_text(encoding='utf-8'))
    else:
        password = secrets.token_urlsafe(15)
        account = dict(username='admin', password_hash=generate_password_hash(password),
                       secret=secrets.token_hex(32))
        path.write_text(json.dumps(account), encoding='utf-8')
        (directory / '管理員登入資訊.txt').write_text(
            '管理員後台：http://127.0.0.1:5000/admin\n帳號：admin\n密碼：' + password +
            '\n\n此檔只供本機管理員使用，請勿提交至版本庫。\n', encoding='utf-8')
    app.secret_key = os.getenv('FUZZY_SECRET_KEY') or account['secret']
    app.config.update(ADMIN_USERNAME=os.getenv('FUZZY_ADMIN_USER', account['username']),
                      ADMIN_PASSWORD_HASH=(generate_password_hash(os.environ['FUZZY_ADMIN_PASSWORD'])
                                           if os.getenv('FUZZY_ADMIN_PASSWORD') else account['password_hash']),
                      SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE='Strict',
                      PERMANENT_SESSION_LIFETIME=timedelta(hours=4), MAX_CONTENT_LENGTH=256*1024)


def admin_required(function):
    @wraps(function)
    def wrapped(*args, **kwargs):
        if session.get('role') != 'admin':
            return jsonify(message='請先以管理員身分登入。'), 401
        if request.method not in ('GET', 'HEAD'):
            token = request.headers.get('X-CSRF-Token', '')
            if not hmac.compare_digest(token, session.get('csrf', '')) or not token:
                return jsonify(message='登入驗證已失效，請重新登入。'), 403
        return function(*args, **kwargs)
    return wrapped


_attempts = {}


def login():
    # JSON + same-origin policy prevents cross-site form logins.
    if not request.is_json:
        return jsonify(message='請使用 JSON 登入。'), 400
    origin = request.headers.get('Origin')
    if origin and origin != request.host_url.rstrip('/'):
        return jsonify(message='不接受跨網站登入。'), 403
    ip = request.remote_addr
    now = time.monotonic()
    attempts = [t for t in _attempts.get(ip, []) if now - t < 300]
    _attempts[ip] = attempts
    if len(attempts) >= 8:
        return jsonify(message='登入嘗試過多，請五分鐘後再試。'), 429
    data = request.get_json(silent=True) or {}
    if not isinstance(data, dict):
        return jsonify(message='登入資料格式不正確。'), 400
    username, password = data.get('username'), data.get('password')
    if (not isinstance(username, str) or not isinstance(password, str) or len(password) > 256
            or not check_password_hash(current_app.config['ADMIN_PASSWORD_HASH'], password)
            or not hmac.compare_digest(username, current_app.config['ADMIN_USERNAME'])):
        attempts.append(now)
        return jsonify(message='帳號或密碼不正確。'), 401
    _attempts.pop(ip, None)
    session.clear()
    session.permanent = True
    session.update(role='admin', username=username, csrf=secrets.token_hex(32))
    return jsonify(username=username, role='admin', csrf=session['csrf'])
