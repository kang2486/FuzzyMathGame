"""Administrator authoring, bounded rule validation and transactional persistence."""
import ast
from datetime import datetime, timezone
import hashlib
from itertools import product
import json
from pathlib import Path
import random
import re

from flask import Blueprint, current_app, jsonify, request, session
import mysql.connector

from admin_auth import admin_required, login
from dev_bank import connect, generate_from_spec

bp = Blueprint('admin_bank', __name__, url_prefix='/api/admin')
bp.add_url_rule('/login', view_func=login, methods=['POST'])


@bp.errorhandler(ValueError)
def invalid(error):
    return jsonify(message=str(error)), 400


@bp.errorhandler(mysql.connector.Error)
def database_error(error):
    current_app.logger.exception('管理題庫資料庫錯誤')
    return jsonify(message='題庫暫時無法連線，請確認 MySQL 服務及目前專案的啟動視窗。'), 503


@bp.get('/session')
@admin_required
def whoami():
    return jsonify(username=session['username'], role='admin', csrf=session['csrf'])


@bp.post('/logout')
@admin_required
def logout():
    session.clear()
    return jsonify(status='success')


def text(value, label, maximum=4000, optional=False):
    if not isinstance(value, str) or len(value) > maximum or (not optional and not value.strip()):
        raise ValueError(f'{label} 必須填寫，且長度不能超過 {maximum} 字。')
    return value.strip()


def integer(value, label, low, high):
    if type(value) is not int or not low <= value <= high:
        raise ValueError(f'{label} 必須是 {low}～{high} 的整數。')
    return value


def array(value, label, low, high):
    if not isinstance(value, list) or not low <= len(value) <= high:
        raise ValueError(f'{label} 必須有 {low}～{high} 筆。')
    if any(not isinstance(item, dict) for item in value):
        raise ValueError(f'{label} 格式不正確。')
    return value


def identifier(value, label):
    value = text(value, label, 32)
    if not re.fullmatch(r'[A-Za-z][A-Za-z0-9_]{0,31}', value) or value == 'value':
        raise ValueError(f'{label} 請用英文字母開頭，搭配數字或底線；value 為保留名稱。')
    return value


def rule(source, names, label):
    source = text(source, label, 200)
    try:
        tree = ast.parse(source, mode='eval')
    except (SyntaxError, RecursionError):
        raise ValueError(f'{label} 的運算式格式不正確。') from None
    nodes = list(ast.walk(tree))
    allowed = (ast.Expression, ast.BinOp, ast.UnaryOp, ast.Constant, ast.Name, ast.Load,
               ast.Add, ast.Sub, ast.Mult, ast.Div, ast.Pow, ast.USub, ast.UAdd)
    if len(nodes) > 80 or any(not isinstance(n, allowed) for n in nodes):
        raise ValueError(f'{label} 只允許參數與 + - * / **，不能呼叫程式或函式。')
    for node in nodes:
        if isinstance(node, ast.Name) and node.id not in names:
            raise ValueError(f'{label} 使用未定義的參數：{node.id}')
        if isinstance(node, ast.Constant) and (type(node.value) is not int or abs(node.value) > 10000):
            raise ValueError(f'{label} 的常數請用整數，分數可寫成 1/2。')
    return source


def template(source, names, label, optional=False):
    source = text(source, label, optional=optional)
    references = set(re.findall(r'\{\{([A-Za-z_][A-Za-z0-9_]*)\}\}', source))
    if references - names:
        raise ValueError(f'{label} 使用未定義的參數：{", ".join(sorted(references-names))}')
    # LaTeX braces are permitted; reject incomplete/invalid placeholder names.
    stripped = re.sub(r'\{\{[A-Za-z_][A-Za-z0-9_]*\}\}', '', source)
    if '{{' in stripped:
        raise ValueError(f'{label} 的參數格式應為 {{{{a}}}}。')
    return source


def validate_document(data):
    if not isinstance(data, dict):
        raise ValueError('請提供有效的題目資料。')
    type_id = text(data.get('type_id'), '題型代碼', 16)
    if not re.fullmatch(r'[A-Z][A-Z0-9_]{1,15}', type_id):
        raise ValueError('題型代碼請用 2～16 個大寫英文字母、數字或底線。')
    result = dict(type_id=type_id, type_name=text(data.get('type_name'), '題型名稱', 100),
                  chapter=integer(data.get('chapter'), '章節', 1, 8),
                  difficulty=integer(data.get('difficulty'), '難度', 1, 5),
                  status=data.get('status'), source_note=text(data.get('source_note', ''), '來源備註', optional=True))
    if result['status'] not in ('draft', 'published'):
        raise ValueError('狀態必須為草稿或已發布。')
    names, parameters = set(), []
    for param in array(data.get('parameters'), '參數', 0, 10):
        name = identifier(param.get('parameter_name'), '參數名稱')
        if name in names:
            raise ValueError(f'參數名稱重複：{name}')
        names.add(name)
        low = integer(param.get('min_value'), '參數下限', -10000, 10000)
        high = integer(param.get('max_value'), '參數上限', -10000, 10000)
        if low > high or high-low > 2000:
            raise ValueError('參數下限不得大於上限，單一範圍寬度不得超過 2000。')
        parameters.append(dict(parameter_name=name, min_value=low, max_value=high))
    result['parameters'] = parameters
    derived = data.get('derived_values', [])
    if not isinstance(derived, list) or len(derived) > 16:
        raise ValueError('衍生值最多 16 筆。')
    derived_names, result['derived_values'] = set(), []
    for item in derived:
        if not isinstance(item, list) or len(item) != 2:
            raise ValueError('衍生值必須包含名稱與運算式。')
        name = identifier(item[0], '衍生值名稱')
        if name in derived_names:
            raise ValueError(f'衍生值名稱重複：{name}')
        result['derived_values'].append([name, rule(item[1], names, '衍生值運算式')])
        derived_names.add(name)
        names.add(name)
    result.update(question_template=template(data.get('question_template'), names, '題幹'),
                  question_latex_template=template(data.get('question_latex_template', ''), names, '題目公式', optional=True),
                  answer_rule=rule(data.get('answer_rule'), names, '答案運算式'))
    result['steps'] = []
    for order, step in enumerate(array(data.get('steps'), '解題步驟', 1, 10), 1):
        value_rule = rule(step.get('value_rule'), names, f'步驟 {order} 運算式')
        fields = dict(step_order=order, value_rule=value_rule,
                      display_template=template(step.get('display_template'), names | {'value'}, f'步驟 {order} 標準解法'),
                      hint=template(step.get('hint'), names, f'步驟 {order} 提示'), rules=[])
        codes = set()
        for option in array(step.get('rules'), '每步選項', 4, 4):
            code = text(option.get('misconception_code'), '觀念代碼', 64)
            if not re.fullmatch(r'[A-Z][A-Z0-9_]{0,63}', code) or code in codes:
                raise ValueError('每個選項必須有不同的大寫觀念代碼。')
            codes.add(code)
            fields['rules'].append(dict(value_rule=value_rule, misconception_code=code,
                option_template=template(option.get('option_template'), names | {'value'}, '選項文字'),
                explanation=template(option.get('explanation', ''), names, '錯誤說明', optional=code == 'CORRECT')))
        if 'CORRECT' not in codes:
            raise ValueError('每步必須標記一個正確選項。')
        result['steps'].append(fields)
    result['spec_id'] = data.get('spec_id') or f'{type_id}_ADMIN_D{result["difficulty"]}'
    # Bounded checks cover endpoints and random values, not a proof of all maths.
    samples = [{p['parameter_name']: p[bound] for p in parameters} for bound in ('min_value', 'max_value')]
    if len(parameters) <= 6:
        samples += [dict(zip([p['parameter_name'] for p in parameters], values))
                    for values in product(*[(p['min_value'], p['max_value']) for p in parameters])]
    rng = random.Random(42)
    samples += [{p['parameter_name']: rng.randint(p['min_value'], p['max_value']) for p in parameters} for _ in range(30)]
    for values in samples:
        try:
            generate_from_spec(result, parameter_values=values, rng=rng)
        except (ValueError, ZeroDivisionError, KeyError, OverflowError, SyntaxError) as exc:
            raise ValueError(f'參數檢查未通過（{values}）：{exc}') from None
    return result


def get_document(cursor, spec_id):
    cursor.execute('SELECT s.*,t.name AS type_name,t.chapter FROM question_spec s '
                   'JOIN question_type t ON s.type_id=t.type_id WHERE s.spec_id=%s', (spec_id,))
    spec = cursor.fetchone()
    if not spec:
        return None
    if isinstance(spec['derived_values'], str):
        spec['derived_values'] = json.loads(spec['derived_values'])
    cursor.execute('SELECT parameter_name,min_value,max_value FROM spec_parameter WHERE spec_id=%s ORDER BY parameter_name', (spec_id,))
    spec['parameters'] = cursor.fetchall()
    cursor.execute('SELECT step_id,step_order,display_template,value_rule,hint FROM solution_step WHERE spec_id=%s ORDER BY step_order', (spec_id,))
    spec['steps'] = cursor.fetchall()
    for step in spec['steps']:
        cursor.execute('SELECT option_order,value_rule,misconception_code,explanation,option_template '
                       'FROM solution_option WHERE step_id=%s ORDER BY option_order', (step['step_id'],))
        step['rules'] = cursor.fetchall()
    spec['revision'] = hashlib.sha256(json.dumps(spec, sort_keys=True, ensure_ascii=False).encode()).hexdigest()
    return spec


@bp.get('/catalog')
@admin_required
def catalog():
    connection = connect()
    try:
        cursor = connection.cursor(dictionary=True)
        cursor.execute('SELECT * FROM chapter ORDER BY chapter')
        chapters = cursor.fetchall()
        cursor.execute('SELECT s.spec_id,s.type_id,s.difficulty,s.status,t.name AS type_name,t.chapter '
                       'FROM question_spec s JOIN question_type t ON s.type_id=t.type_id '
                       'ORDER BY t.chapter,s.type_id,s.difficulty')
        return jsonify(chapters=chapters, specs=cursor.fetchall())
    finally:
        connection.close()


@bp.get('/specs/<spec_id>')
@admin_required
def detail(spec_id):
    connection = connect()
    try:
        document = get_document(connection.cursor(dictionary=True), spec_id)
        return (jsonify(document) if document else (jsonify(message='找不到題目規格。'), 404))
    finally:
        connection.close()


@bp.post('/preview')
@admin_required
def preview():
    document = validate_document(request.get_json(silent=True))
    questions = [generate_from_spec(document) for _ in range(3)]
    return jsonify(questions=questions, message='已通過參數端點與抽樣檢查；請再人工核對數學意義與誘答是否正確。')


@bp.route('/specs', methods=['POST'])
@bp.route('/specs/<spec_id>', methods=['PUT'])
@admin_required
def save(spec_id=None):
    data = request.get_json(silent=True)
    document = validate_document(data)
    connection = connect()
    try:
        cursor = connection.cursor(dictionary=True)
        # Lock shared type metadata to serialize edits across difficulty variants.
        cursor.execute('SELECT * FROM question_type WHERE type_id=%s FOR UPDATE', (document['type_id'],))
        existing_type = cursor.fetchone()
        if existing_type and existing_type['chapter'] != document['chapter']:
            raise ValueError('此題型已屬於其他章節；請另建題型代碼。')
        old = None
        if spec_id:
            cursor.execute('SELECT spec_id FROM question_spec WHERE spec_id=%s FOR UPDATE', (spec_id,))
            cursor.fetchall()
            old = get_document(cursor, spec_id)
            if not old:
                return jsonify(message='找不到要修改的題目。'), 404
            if data.get('revision') != old['revision']:
                return jsonify(message='題目已被另一個編輯更新，請重新載入後再修改。'), 409
            if (old['type_id'], old['difficulty']) != (document['type_id'], document['difficulty']):
                raise ValueError('修改既有規格不能變更題型代碼或難度，請使用「複製為新規格」。')
            document['spec_id'] = spec_id
        else:
            document['spec_id'] = f'{document["type_id"]}_ADMIN_D{document["difficulty"]}'
            cursor.execute('SELECT spec_id FROM question_spec WHERE type_id=%s AND difficulty=%s',
                           (document['type_id'], document['difficulty']))
            if cursor.fetchone():
                return jsonify(message='此題型已有相同難度，請選取該規格編輯。'), 409
        if old:
            backup_dir = Path(current_app.root_path).parent / '.local' / 'question-backups'
            backup_dir.mkdir(parents=True, exist_ok=True)
            stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
            # IDs come from DB, never from a client-controlled filesystem path.
            safe_id = hashlib.sha256(spec_id.encode()).hexdigest()[:16]
            (backup_dir / f'{stamp}_{safe_id}.json').write_text(
                json.dumps(dict(editor=session['username'], document=old), ensure_ascii=False, indent=2), encoding='utf-8')
        if not existing_type:
            cursor.execute('INSERT INTO question_type(type_id,chapter,name) VALUES (%s,%s,%s)',
                           (document['type_id'], document['chapter'], document['type_name']))
        else:
            cursor.execute('UPDATE question_type SET name=%s WHERE type_id=%s', (document['type_name'], document['type_id']))
        values = tuple(document[key] for key in ('type_id','difficulty','question_template','question_latex_template'))
        tail = (json.dumps(document['derived_values']), document['answer_rule'], document['status'], document['source_note'])
        if old:
            cursor.execute('UPDATE question_spec SET type_id=%s,difficulty=%s,question_template=%s,'
                           'question_latex_template=%s,derived_values=%s,answer_rule=%s,status=%s,source_note=%s '
                           'WHERE spec_id=%s', (*values, *tail, document['spec_id']))
            cursor.execute('DELETE o FROM solution_option o JOIN solution_step s ON o.step_id=s.step_id WHERE s.spec_id=%s', (spec_id,))
            cursor.execute('DELETE FROM solution_step WHERE spec_id=%s', (spec_id,))
            cursor.execute('DELETE FROM spec_parameter WHERE spec_id=%s', (spec_id,))
        else:
            cursor.execute('INSERT INTO question_spec(spec_id,type_id,difficulty,question_template,question_latex_template,'
                           'derived_values,answer_rule,status,source_note) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s)',
                           (document['spec_id'], *values, *tail))
        for param in document['parameters']:
            cursor.execute('INSERT INTO spec_parameter VALUES (%s,%s,%s,%s)',
                           (document['spec_id'], param['parameter_name'], param['min_value'], param['max_value']))
        for step in document['steps']:
            step_id = f'{document["spec_id"]}_S{step["step_order"]}'
            cursor.execute('INSERT INTO solution_step VALUES (%s,%s,%s,%s,%s,%s)',
                           (step_id, document['spec_id'], step['step_order'], step['display_template'], step['value_rule'], step['hint']))
            for order, option in enumerate(step['rules'], 1):
                cursor.execute('INSERT INTO solution_option '
                               '(step_id,option_order,value_rule,misconception_code,explanation,option_template) VALUES (%s,%s,%s,%s,%s,%s)',
                               (step_id, order, option['value_rule'], option['misconception_code'], option['explanation'], option['option_template']))
        connection.commit()
        return jsonify(status='success', document=get_document(cursor, document['spec_id'])), 200 if old else 201
    except mysql.connector.IntegrityError:
        connection.rollback()
        return jsonify(message='題型或難度已存在，請重新載入清單。'), 409
    except Exception:
        connection.rollback()
        raise
    finally:
        connection.close()
