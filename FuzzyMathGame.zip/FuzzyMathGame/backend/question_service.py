"""Select a published rule by chapter and fuzzy ability, then instantiate it."""
import math
import random

from dev_bank import connect, generate
from fuzzy_difficulty import calculate_memberships, calculate_probabilities


def select_available_difficulty(ability, available):
    probabilities = calculate_probabilities(ability)
    available = sorted(set(available))
    if not available:
        raise LookupError('本章尚無已發布的題目，請先在管理員後台發布。')
    weights = {d: probabilities[d] for d in available}
    fallback = sum(weights.values()) == 0
    if fallback:
        expected = sum(d*p for d, p in probabilities.items())
        nearest = min(abs(d-expected) for d in available)
        weights = {d: float(math.isclose(abs(d-expected), nearest)) for d in available}
    total = sum(weights.values())
    effective = {d: w/total for d, w in weights.items()}
    difficulty = random.choices(available, weights=list(effective.values()), k=1)[0]
    return difficulty, dict(difficulty_memberships=calculate_memberships(ability),
                            difficulty_probabilities=probabilities,
                            available_probabilities=effective, used_nearest_available=fallback)


def next_question(chapter, ability, exclude_type=None):
    connection = connect()
    try:
        cursor = connection.cursor(dictionary=True)
        cursor.execute("SELECT s.type_id,s.difficulty,t.name FROM question_spec s "
                       "JOIN question_type t ON t.type_id=s.type_id "
                       "WHERE t.chapter=%s AND s.status='published' ORDER BY s.type_id,s.difficulty", (chapter,))
        rows = cursor.fetchall()
    finally:
        connection.close()
    difficulty, metadata = select_available_difficulty(ability, [r['difficulty'] for r in rows])
    candidates = [r for r in rows if r['difficulty'] == difficulty]
    preferred = [r for r in candidates if r['type_id'] != exclude_type]
    chosen = random.choice(preferred or candidates)
    question = generate(chosen['type_id'], difficulty)
    question.update(chapter=chapter, type_name=chosen['name'], ability=ability,
                    adaptive=True, **metadata)
    return question
