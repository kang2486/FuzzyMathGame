"""Launch this checkout, checking DB and rejecting a stale server on port 5000."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time
import urllib.error
import urllib.request
import webbrowser

from init_dev_bank import credentials

PROJECT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT / 'backend'))


def health():
    try:
        with urllib.request.urlopen('http://127.0.0.1:5000/api/health', timeout=2) as response:
            return json.load(response)
    except urllib.error.HTTPError:
        return {'status': 'incompatible'}
    except (OSError, ValueError):
        return None


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--check', action='store_true', help='Check DB and generation without starting a server')
    args = parser.parse_args()
    credentials()
    from dev_bank import catalog, generate
    from question_service import next_question
    try:
        chapters = catalog()
        if not chapters:
            raise RuntimeError('題庫沒有已發布的題目。')
        next_question(int(next(iter(chapters))), 50)
        print(f'題庫連線與產題檢查通過：{len(chapters)} 個章節。')
    except Exception as exc:
        print(f'啟動前檢查失敗：{exc}')
        print('請檢查 MySQL80 服務與 FUZZY_DB_* 設定；不要改用其他資料夾的舊啟動檔。')
        return 1
    if args.check:
        return 0
    running = health()
    workspace = hashlib.sha256(str(PROJECT).encode()).hexdigest()[:16]
    if running:
        if running.get('workspace_id') == workspace and running.get('version') == '2026-11-admin' and running.get('status') == 'ok':
            print('目前專案已在執行，直接開啟遊戲。')
            webbrowser.open('http://127.0.0.1:5000/')
            return 0
        print('5000 埠已有其他資料夾或舊版本的後端。請先關閉舊啟動視窗，再執行本檔。')
        print('目前專案：', PROJECT)
        return 1
    print('啟動目前專案：', PROJECT)
    print('遊戲：http://127.0.0.1:5000/  管理員：http://127.0.0.1:5000/admin')
    print('管理員登入資訊位於 .local/管理員登入資訊.txt。保持此視窗開啟，Ctrl+C 停止。')
    process = subprocess.Popen([sys.executable, str(PROJECT/'database/run_dev_server.py')], cwd=PROJECT)
    try:
        for _ in range(25):
            if process.poll() is not None:
                return process.returncode
            ready = health()
            if ready and ready.get('workspace_id') == workspace and ready.get('status') == 'ok':
                webbrowser.open('http://127.0.0.1:5000/')
                break
            time.sleep(.2)
        return process.wait()
    except KeyboardInterrupt:
        process.terminate()
        return 0


if __name__ == '__main__':
    raise SystemExit(main())
