"""Split the project's SQL scripts without splitting quoted text."""


def split_statements(source):
    start = 0
    quote = None
    index = 0
    while index < len(source):
        char = source[index]
        if quote:
            if char == '\\':
                index += 2
                continue
            if char == quote:
                if index + 1 < len(source) and source[index + 1] == quote:
                    index += 2
                    continue
                quote = None
        elif char in ("'", '"', '`'):
            quote = char
        elif char == ';':
            statement = source[start:index].strip()
            if statement:
                yield statement
            start = index + 1
        index += 1
    if quote:
        raise ValueError('SQL contains an unterminated quoted value.')
    if source[start:].strip():
        yield source[start:].strip()
