"""Replace only built-in option rows, backing up existing rows before a transaction.

No question, parameter, hint, or original database is changed. Safe to rerun.
"""
from datetime import datetime, timezone
import json
from pathlib import Path

import mysql.connector
from concept_options import OPTIONS, option_rows
from init_dev_bank import credentials


def main():
    connection = mysql.connector.connect(**credentials(), database='fuzzy_math_game_dev')
    try:
        cursor = connection.cursor(dictionary=True)
        cursor.execute('SELECT s.* FROM solution_step s ORDER BY s.step_id FOR UPDATE')
        steps = {row['step_id']: row for row in cursor.fetchall()}
        expected = {}
        for type_id, authored_steps in OPTIONS.items():
            for difficulty in range(1, 6):
                for order in range(1, len(authored_steps) + 1):
                    step_id = f'{type_id}_DEV_D{difficulty}_S{order}'
                    if step_id not in steps:
                        raise RuntimeError(f'Missing built-in step: {step_id}; no changes made.')
                    expected[step_id] = [dict(step_id=step_id, option_order=index,
                                             value_rule=rule, misconception_code=code,
                                             explanation=explanation, option_template=template)
                                         for index, (rule, code, explanation, template) in enumerate(
                                             option_rows(type_id, order, steps[step_id]['value_rule']), 1)]
        cursor.execute('SELECT * FROM solution_option ORDER BY step_id, option_order FOR UPDATE')
        prior = {step_id: [] for step_id in expected}
        for row in cursor.fetchall():
            if row['step_id'] in prior:
                prior[row['step_id']].append(row)
        changed = [step_id for step_id in expected if prior[step_id] != expected[step_id]]
        if not changed:
            print('Conceptual options already installed; no changes made.')
            return

        backup_dir = Path(__file__).resolve().parent / 'backups'
        backup_dir.mkdir(exist_ok=True)
        timestamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
        backup = backup_dir / f'options_before_concepts_{timestamp}.json'
        backup.write_text(json.dumps(dict(database='fuzzy_math_game_dev', options=prior),
                                     ensure_ascii=False, indent=2), encoding='utf-8')
        for step_id in changed:
            cursor.execute('DELETE FROM solution_option WHERE step_id=%s', (step_id,))
            for row in expected[step_id]:
                cursor.execute('INSERT INTO solution_option '
                               '(step_id,option_order,value_rule,misconception_code,explanation,option_template) '
                               'VALUES (%s,%s,%s,%s,%s,%s)',
                               tuple(row[key] for key in ('step_id', 'option_order', 'value_rule',
                                                        'misconception_code', 'explanation', 'option_template')))
        connection.commit()
        print(f'Updated {len(changed)} steps / {len(changed)*4} options. Backup: {backup}')
    except Exception:
        connection.rollback()
        raise
    finally:
        connection.close()


if __name__ == '__main__':
    main()
