"""Apply additive development-bank migrations without replacing existing rows."""
from init_dev_bank import ROOT, credentials
import mysql.connector


def main():
    connection = mysql.connector.connect(**credentials(), database='fuzzy_math_game_dev')
    try:
        cursor = connection.cursor()
        cursor.execute('SELECT version FROM bank_meta ORDER BY version')
        versions = cursor.fetchall()
        if versions == [(1,), (2,), (3,)]:
            print('Migrations 2 and 3 already applied; no changes made.')
            return
        if versions == [(1,)]:
            for statement in (ROOT/'migration_002.sql').read_text(encoding='utf-8').split(';'):
                if statement.strip():
                    cursor.execute(statement)
            connection.commit()
            cursor.execute('SELECT version FROM bank_meta ORDER BY version')
            versions = cursor.fetchall()
        if versions != [(1,), (2,)]:
            raise RuntimeError('Unexpected database version; stopped without changes.')

        cursor.execute("SELECT COUNT(*) FROM question_type WHERE type_id='L02'")
        if cursor.fetchone()[0]:
            raise RuntimeError('L02 exists without schema version 3; inspect the prior migration before retrying.')
        cursor.execute("SHOW COLUMNS FROM solution_option LIKE 'option_template'")
        if not cursor.fetchone():
            cursor.execute('ALTER TABLE solution_option ADD COLUMN option_template TEXT NULL')
        statements = (ROOT/'migration_003.sql').read_text(encoding='utf-8').split(';')
        for statement in statements:
            normalized = statement.strip()
            if (not normalized or normalized.upper().startswith('USE ') or
                    normalized.upper().startswith('ALTER TABLE')):
                continue
            cursor.execute(normalized)
        connection.commit()
        print('Added the symbolic factor-and-cancel limit type; existing question rows unchanged.')
    except Exception:
        connection.rollback()
        raise
    finally:
        connection.close()


if __name__ == '__main__':
    main()
