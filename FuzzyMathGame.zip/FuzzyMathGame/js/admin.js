"use strict";
const $ = id => document.getElementById(id);
let csrf = "", catalog = [], current = null, dirty = false, busy = false, stepSerial = 0;

function notice(message, error = false) {
    $("notice").textContent = message;
    $("notice").classList.toggle("error", error);
    $("notice").hidden = false;
}

async function api(path, options = {}) {
    const response = await fetch(`/api/admin${path}`, {
        ...options, cache: "no-store", headers: {"Content-Type": "application/json", "X-CSRF-Token": csrf}
    });
    let data;
    try { data = await response.json(); } catch { throw new Error("後端回應異常，請用目前專案的啟動檔重啟服務。"); }
    if (!response.ok) {
        if (response.status === 401 && path !== "/login") showLogin();
        throw new Error(data.message || `請求失敗 (${response.status})`);
    }
    return data;
}

function element(tag, className, content) {
    const item = document.createElement(tag);
    if (className) item.className = className;
    if (content !== undefined) item.textContent = content;
    return item;
}

function button(label, handler, className = "") {
    const item = element("button", className, label);
    item.type = "button";
    item.addEventListener("click", handler);
    return item;
}

function field(parent, title, name, value = "", type = "text") {
    const label = element("label", "", title);
    const input = element(type === "textarea" ? "textarea" : "input");
    if (type !== "textarea") input.type = type;
    else input.rows = 3;
    input.dataset.field = name;
    input.value = value;
    label.append(input); parent.append(label);
    return input;
}

function value(parent, name) { return parent.querySelector(`[data-field="${name}"]`).value.trim(); }

function removeRow(row) {
    row.remove(); dirty = true;
    [...$("steps").children].forEach((step, index) => step.querySelector("h3").textContent = `步驟 ${index + 1}`);
}

function addParameter(param = {}) {
    const row = element("div", "parameter-row");
    field(row, "參數名稱", "parameter_name", param.parameter_name || "");
    field(row, "最小值", "min_value", param.min_value ?? 1, "number");
    field(row, "最大值", "max_value", param.max_value ?? 5, "number");
    row.append(button("移除", () => removeRow(row), "remove"));
    $("parameters").append(row);
}

function addDerived(item = ["", ""]) {
    const row = element("div", "derived-row");
    field(row, "衍生值名稱", "name", item[0]);
    field(row, "運算式（依序計算）", "rule", item[1]);
    row.append(button("移除", () => removeRow(row), "remove"));
    $("derived").append(row);
}

function addStep(step = {}) {
    const card = element("section", "step-card");
    const top = element("div", "step-top");
    top.append(element("h3", "", `步驟 ${$("steps").children.length + 1}`), button("移除步驟", () => removeRow(card), "remove"));
    card.append(top);
    field(card, "標準解法／步驟內容", "display_template", step.display_template || "", "textarea");
    field(card, "本步驟的數值運算式", "value_rule", step.value_rule || "");
    field(card, "文字解題提示（使用提示時顯示）", "hint", step.hint || "", "textarea");
    const options = element("div", "options-grid");
    const radioName = `correct-option-${++stepSerial}`;
    const rules = step.rules || Array.from({length: 4}, (_, i) => ({misconception_code: i ? `ERROR_${i}` : "CORRECT"}));
    rules.forEach((rule, i) => {
        const option = element("div", "option-card");
        const heading = element("div", "option-top");
        heading.append(element("strong", "", `選項 ${i + 1}`));
        const label = element("label", "", "正確選項");
        const radio = document.createElement("input");
        radio.type = "radio"; radio.name = radioName; radio.checked = rule.misconception_code === "CORRECT";
        label.prepend(radio); heading.append(label); option.append(heading);
        field(option, "選項文字／公式", "option_template", rule.option_template || "", "textarea");
        field(option, "觀念代碼（例如 WRONG_SIGN）", "misconception_code", rule.misconception_code || `ERROR_${i+1}`);
        field(option, "選錯後的觀念說明（正解可留空）", "explanation", rule.explanation || "", "textarea");
        options.append(option);
    });
    card.append(options); $("steps").append(card);
}

function collect() {
    return {
        spec_id: current?.spec_id, revision: current?.revision,
        type_id: $("type-id").value.trim(), type_name: $("type-name").value.trim(),
        chapter: Number($("chapter").value), difficulty: Number($("difficulty").value),
        status: $("status").value, source_note: $("source-note").value.trim(),
        question_template: $("question-template").value.trim(), question_latex_template: $("question-latex").value.trim(),
        answer_rule: $("answer-rule").value.trim(),
        parameters: [...$("parameters").children].map(row => ({parameter_name: value(row,"parameter_name"), min_value: Number(value(row,"min_value")), max_value: Number(value(row,"max_value"))})),
        derived_values: [...$("derived").children].map(row => [value(row,"name"), value(row,"rule")]),
        steps: [...$("steps").children].map(card => ({display_template: value(card,"display_template"), value_rule: value(card,"value_rule"), hint: value(card,"hint"),
            rules: [...card.querySelectorAll(".option-card")].map((option, i) => {
                const correct = option.querySelector("input[type=radio]").checked;
                const code = value(option,"misconception_code");
                return {misconception_code: correct ? "CORRECT" : (code === "CORRECT" ? `ERROR_${i+1}` : code),
                    option_template: value(option,"option_template"), explanation: value(option,"explanation")};
            })}))
    };
}

const example = {
    type_id: "ALG01", type_name: "一次方程式：等式的反向運算", chapter: 1, difficulty: 1, status: "draft", source_note: "自編示範，可修改參數範圍與誘答。",
    question_template: "解方程式 {{a}}x + {{b}} = {{rhs}}。", question_latex_template: "{{a}}x+{{b}}={{rhs}}", answer_rule: "x",
    parameters: [{parameter_name:"a",min_value:2,max_value:5},{parameter_name:"b",min_value:1,max_value:6},{parameter_name:"x",min_value:2,max_value:7}],
    derived_values: [["rhs","a*x+b"]],
    steps: [{display_template:"兩邊同減 {{b}}：{{a}}x = {{value}}",value_rule:"rhs-b",hint:"想消去左邊的常數項，等式左右兩邊要做相同的運算。",rules:[
        {misconception_code:"CORRECT",option_template:"兩邊同減 {{b}}，得到 \\({{a}}x={{rhs}}-{{b}}\\)。",explanation:""},
        {misconception_code:"MOVE_WITHOUT_SIGN",option_template:"常數移項不變號，得到 \\({{a}}x={{rhs}}+{{b}}\\)。",explanation:"移項是兩邊做反向運算；消去正的常數項應兩邊同減。"},
        {misconception_code:"ONE_SIDE_ONLY",option_template:"只減去左邊的常數，得到 \\({{a}}x={{rhs}}\\)。",explanation:"只改等式一邊會破壞原有的相等關係。"},
        {misconception_code:"UNLIKE_TERMS",option_template:"把常數併入 x 的係數，得到 \\(({{a}}+{{b}})x={{rhs}}\\)。",explanation:"含有 x 的項與常數不是同類項。"}]},
        {display_template:"兩邊同除以 {{a}}，得到 x={{value}}。",value_rule:"x",hint:"x 前面的係數是乘法關係，要用相反運算消去。",rules:[
        {misconception_code:"CORRECT",option_template:"兩邊同除以 {{a}}：\\(x=({{rhs}}-{{b}})/{{a}}\\)。",explanation:""},
        {misconception_code:"MULTIPLY_COEFFICIENT",option_template:"兩邊乘以係數：\\(x=({{rhs}}-{{b}})\\times{{a}}\\)。",explanation:"要消去乘在 x 上的係數，應用除法。"},
        {misconception_code:"DIVIDE_ONE_TERM",option_template:"只除右邊第一項：\\(x={{rhs}}/{{a}}-{{b}}\\)。",explanation:"右邊的整個式子都要除以係數，不能漏掉一項。"},
        {misconception_code:"SUBTRACT_COEFFICIENT",option_template:"將乘法係數移到右邊相減：\\(x={{rhs}}-{{b}}-{{a}}\\)。",explanation:"乘法係數不能當加法常數移項。"}]}]
};

function mayLeave() { return !dirty || window.confirm("有尚未儲存的修改，要離開目前編輯嗎？"); }

function edit(document, isCopy = false) {
    current = isCopy ? null : document;
    $("empty-editor").hidden = true; $("editor").hidden = false;
    const mapping = {"type-id":"type_id","type-name":"type_name","chapter":"chapter","difficulty":"difficulty","status":"status","source-note":"source_note","question-template":"question_template","question-latex":"question_latex_template","answer-rule":"answer_rule"};
    Object.entries(mapping).forEach(([id,key]) => {$(id).value = document[key] ?? "";});
    $("type-id").disabled = Boolean(current?.spec_id); $("difficulty").disabled = Boolean(current?.spec_id);
    $("chapter").disabled = Boolean(current?.spec_id);
    for (const id of ["parameters","derived","steps"]) $(id).replaceChildren();
    (document.parameters || []).forEach(addParameter); (document.derived_values || []).forEach(addDerived); (document.steps || []).forEach(addStep);
    $("editor-title").textContent = current?.spec_id ? document.type_name : "新增題目規格";
    $("editor-mode").textContent = current?.spec_id ? document.spec_id : "NEW SPECIFICATION";
    $("duplicate").disabled = !current?.spec_id;
    dirty = isCopy; renderList();
}

function renderList() {
    const query = $("search").value.toLowerCase(), chapter = $("chapter-filter").value, status = $("status-filter").value;
    const rows = catalog.filter(item => (!chapter || String(item.chapter) === chapter) && (!status || item.status === status) && `${item.type_name} ${item.type_id}`.toLowerCase().includes(query));
    $("spec-list").replaceChildren();
    rows.forEach(item => {
        const entry = button("", async () => {
            if (busy || !mayLeave()) return;
            try {edit(await api(`/specs/${encodeURIComponent(item.spec_id)}`));} catch(error) {notice(error.message,true);}
        }, "spec-item");
        entry.classList.toggle("active", item.spec_id === current?.spec_id);
        entry.append(element("strong","",item.type_name),element("small","",`第 ${item.chapter} 章 · ${item.type_id} · 難度 ${item.difficulty} · ${item.status === "published" ? "已發布" : "草稿"}`));
        $("spec-list").append(entry);
    });
    if (!rows.length) $("spec-list").append(element("p","help","沒有符合篩選條件的規格。"));
}

async function refreshCatalog() {
    const data = await api("/catalog"); catalog = data.specs;
    for (const id of ["chapter","chapter-filter"]) {
        const selected = $(id).value;
        $(id).replaceChildren();
        if (id === "chapter-filter") $(id).append(new Option("全部章節",""));
        data.chapters.forEach(c => $(id).append(new Option(`${c.chapter}. ${c.name}`,c.chapter)));
        if ([...$(id).options].some(o => o.value === selected)) $(id).value = selected;
    }
    $("published-count").textContent = catalog.filter(s => s.status === "published").length;
    $("draft-count").textContent = catalog.filter(s => s.status === "draft").length;
    renderList();
}

function showLogin() {
    csrf = ""; $("workspace").hidden = true; $("login-view").hidden = false;
    $("logout").hidden = true; $("session-name").textContent = "";
}

async function enter(data) {
    csrf = data.csrf; $("session-name").textContent = `${data.username} · 管理員`;
    $("logout").hidden = false; $("login-view").hidden = true; $("workspace").hidden = false;
    await refreshCatalog();
}

async function runBusy(task) {
    if (busy) return;
    busy = true;
    $("editor").inert = true;
    for (const id of ["save","preview","duplicate","new-spec"]) $(id).disabled = true;
    try {await task();} catch (error) {notice(error.message,true);}
    finally {
        busy = false;
        $("editor").inert = false;
        for (const id of ["save","preview","new-spec"]) $(id).disabled = false;
        $("duplicate").disabled = !current?.spec_id;
    }
}

function showPreview(data) {
    $("preview-note").textContent = data.message;
    $("preview-content").replaceChildren();
    data.questions.forEach((question, index) => {
        const card = element("section","preview-question");
        card.append(element("h3","",`預覽 ${index+1} · 難度 ${question.difficulty}`),element("p","",question.question_text));
        if (question.question_latex) card.append(element("div","preview-math",`\\(${question.question_latex}\\)`));
        card.append(element("p","help",`本次參數：${Object.entries(question.parameters).map(([k,v]) => `${k}=${v}`).join("，")}｜答案數值：${question.answer_value}`));
        question.steps.forEach((step, i) => {
            const section = element("div","preview-step");
            section.append(element("strong","",`步驟 ${i+1}`),element("p","help",`提示：${step.hint}`));
            step.options.forEach(option => {
                const row = element("div",`preview-option${option.is_correct ? " correct" : ""}`,`${option.is_correct ? "✓ 正解　" : "誘答　"}${option.text}`);
                if (option.explanation) row.append(element("small","",`選錯說明：${option.explanation}`));
                section.append(row);
            }); card.append(section);
        }); $("preview-content").append(card);
    });
    if (window.renderMathInElement) window.renderMathInElement($("preview-content"),{delimiters:[{left:"\\(",right:"\\)",display:false},{left:"$$",right:"$$",display:true}],throwOnError:false});
    $("preview-dialog").showModal();
}

$("login-form").addEventListener("submit", async event => {
    event.preventDefault(); const submit = event.submitter; submit.disabled = true;
    try {await enter(await api("/login",{method:"POST",body:JSON.stringify({username:$("username").value,password:$("password").value})})); $("password").value=""; $("notice").hidden=true;}
    catch(error) {notice(error.message,true);} finally {submit.disabled=false;}
});
$("logout").addEventListener("click", async () => {if (busy || !mayLeave()) return; try {await api("/logout",{method:"POST"}); dirty=false;current=null;$("editor").hidden=true;$("empty-editor").hidden=false;showLogin();} catch(error){notice(error.message,true);}});
$("new-spec").addEventListener("click", () => {if(mayLeave()) edit({...example,type_id:"",type_name:"",parameters:[],derived_values:[],steps:[],question_template:"",question_latex_template:"",answer_rule:"",source_note:""},true);});
$("use-example").addEventListener("click", () => edit(structuredClone(example),true));
$("duplicate").addEventListener("click", () => {const copy=collect();copy.status="draft";edit(copy,true);notice("已複製成草稿。請變更題型代碼或難度，再預覽、儲存。");});
$("add-parameter").addEventListener("click", () => {addParameter();dirty=true;});
$("add-derived").addEventListener("click", () => {addDerived();dirty=true;});
$("add-step").addEventListener("click", () => {addStep();dirty=true;});
$("editor").addEventListener("input", () => {dirty=true;});
$("editor").addEventListener("change", () => {dirty=true;});
$("editor").addEventListener("submit", event => {
    event.preventDefault();
    runBusy(async () => {
        const saved = await api(current?.spec_id ? `/specs/${encodeURIComponent(current.spec_id)}` : "/specs", {method:current?.spec_id ? "PUT" : "POST",body:JSON.stringify(collect())});
        await refreshCatalog(); edit(saved.document); dirty=false;
        notice(saved.document.status === "published" ? "已儲存並發布，學生遊戲下一題即可抽到這份規格。" : "草稿已儲存，不會加入學生遊戲。");
    });
});
$("preview").addEventListener("click", () => runBusy(async () => showPreview(await api("/preview",{method:"POST",body:JSON.stringify(collect())}))));
$("close-preview").addEventListener("click", () => $("preview-dialog").close());
$("refresh-list").addEventListener("click", () => runBusy(refreshCatalog));
for(const id of ["search","chapter-filter","status-filter"]) $(id).addEventListener(id === "search" ? "input" : "change",renderList);
window.addEventListener("beforeunload",event => {if(dirty){event.preventDefault();event.returnValue="";}});

(async () => {
    try {const response=await fetch("/api/health",{cache:"no-store"});const data=await response.json();$("connection-state").textContent=response.ok ? `題庫已連線 · ${data.chapters} 個可用章節` : data.message;}
    catch {$("connection-state").textContent="無法連線目前版本的後端，請由此專案的啟動檔開啟遊戲。";}
    try {await enter(await api("/session"));} catch(error) {if(csrf) notice(error.message,true);}
})();
