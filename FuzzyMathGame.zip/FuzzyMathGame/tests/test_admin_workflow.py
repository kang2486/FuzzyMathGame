"""Integration tests in a disposable DB; never edit the installed question bank."""
from copy import deepcopy
import os
from pathlib import Path
import sys
import unittest
import uuid

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT/'backend'), str(ROOT/'database')]
import mysql.connector
from werkzeug.security import generate_password_hash
from init_dev_bank import credentials
from sql_statements import split_statements
from app import app
from admin_bank import validate_document
from question_service import select_available_difficulty


def document():
    return dict(type_id='TEST01', type_name='管理員整合測試', chapter=1, difficulty=3,
                status='draft', source_note='測試資料', question_template='解 {{a}}x+{{b}}={{rhs}}。',
                question_latex_template='{{a}}x+{{b}}={{rhs}}', answer_rule='x',
                parameters=[dict(parameter_name='a',min_value=2,max_value=5),
                            dict(parameter_name='b',min_value=1,max_value=4),
                            dict(parameter_name='x',min_value=2,max_value=5)],
                derived_values=[['rhs','a*x+b']], steps=[dict(display_template='x={{value}}',value_rule='x',
                hint='等式兩邊先同減 {{b}}，再同除以 {{a}}。', rules=[
                    dict(misconception_code='CORRECT',option_template='x=({{rhs}}-{{b}})/{{a}}',explanation=''),
                    dict(misconception_code='WRONG_SIGN',option_template='x=({{rhs}}+{{b}})/{{a}}',explanation='減去常數項。'),
                    dict(misconception_code='MULTIPLY',option_template='x=({{rhs}}-{{b}})*{{a}}',explanation='消去乘法係數應用除法。'),
                    dict(misconception_code='ONE_TERM',option_template='x={{rhs}}/{{a}}-{{b}}',explanation='整個右式都要除以係數。')])])


class ValidationTests(unittest.TestCase):
    def test_reject_unsafe_rule_and_unknown_reference(self):
        for bad in ["__import__('os')", 'x.__class__', 'unknown+1', '[1][0]', '2**100']:
            data = document(); data['answer_rule'] = bad
            with self.assertRaises(ValueError): validate_document(data)
        data = document(); data['question_template'] = '未知 {{ghost}}'
        with self.assertRaises(ValueError): validate_document(data)

    def test_parameter_boundary_zero_division_rejected(self):
        data=document(); data['parameters'][0]['min_value']=0
        data['answer_rule']='(rhs-b)/a'
        with self.assertRaises(ValueError): validate_document(data)

    def test_nearest_published_difficulty_and_ability_endpoints(self):
        difficulty, metadata=select_available_difficulty(50,[5])
        self.assertEqual(difficulty,5); self.assertTrue(metadata['used_nearest_available'])
        for ability,expected in [(0,1),(25,2),(50,3),(75,4),(100,5)]:
            self.assertEqual(select_available_difficulty(ability,[1,2,3,4,5])[0],expected)
        with self.assertRaises(LookupError): select_available_difficulty(50,[])


class AdminWorkflowTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.original_db=os.environ.get('FUZZY_DB_NAME')
        cls.original_mode=os.environ.get('FUZZY_DATA_MODE')
        cls.name='fuzzy_admin_test_'+uuid.uuid4().hex[:12]
        cls.connection=mysql.connector.connect(**credentials())
        cursor=cls.connection.cursor()
        for statement in split_statements((ROOT/'database/schema.sql').read_text(encoding='utf-8').replace('fuzzy_math_game_dev',cls.name)):
            cursor.execute(statement)
        for chapter in range(1,9): cursor.execute('INSERT INTO chapter VALUES (%s,%s)',(chapter,f'測試章節{chapter}'))
        cls.connection.commit()
        os.environ['FUZZY_DB_NAME']=cls.name; os.environ['FUZZY_DATA_MODE']='mysql_dev'
        app.config.update(TESTING=True,ADMIN_USERNAME='admin',ADMIN_PASSWORD_HASH=generate_password_hash('test-password'))

    @classmethod
    def tearDownClass(cls):
        if cls.name.startswith('fuzzy_admin_test_') and len(cls.name)==29:
            cls.connection.cursor().execute('DROP DATABASE `'+cls.name+'`')
        cls.connection.close()
        for name,prior in [('FUZZY_DB_NAME',cls.original_db),('FUZZY_DATA_MODE',cls.original_mode)]:
            if prior is None: os.environ.pop(name,None)
            else: os.environ[name]=prior

    def test_full_author_preview_draft_publish_edit_unpublish(self):
        client=app.test_client()
        self.assertEqual(client.get('/api/admin/catalog').status_code,401)
        self.assertEqual(client.post('/api/admin/login',json={'username':'admin','password':'wrong'}).status_code,401)
        logged=client.post('/api/admin/login',json={'username':'admin','password':'test-password'})
        self.assertEqual(logged.status_code,200)
        headers={'X-CSRF-Token':logged.json['csrf']}
        data=document()
        self.assertEqual(client.post('/api/admin/preview',json=data).status_code,403)
        preview=client.post('/api/admin/preview',json=data,headers=headers)
        self.assertEqual(preview.status_code,200,preview.json)
        self.assertEqual(len(preview.json['questions']),3)
        draft=client.post('/api/admin/specs',json=data,headers=headers)
        self.assertEqual(draft.status_code,201,draft.json)
        self.assertEqual(client.get('/api/questions/next?chapter=1&ability=50').status_code,404)
        saved=draft.json['document']; saved['status']='published'
        published=client.put('/api/admin/specs/'+saved['spec_id'],json=saved,headers=headers)
        self.assertEqual(published.status_code,200,published.json)
        public=client.get('/api/questions/next?chapter=1&ability=50')
        self.assertEqual(public.status_code,200,public.json)
        self.assertEqual(public.json['type_id'],'TEST01')
        self.assertEqual(public.json['difficulty'],3)
        self.assertNotIn('{{',public.json['steps'][0]['hint'])
        self.assertEqual(client.put('/api/admin/specs/'+saved['spec_id'],json=saved,headers=headers).status_code,409)
        edited=published.json['document']; edited['question_template']='修改後：{{a}}x+{{b}}={{rhs}}'
        changed=client.put('/api/admin/specs/'+saved['spec_id'],json=edited,headers=headers)
        self.assertEqual(changed.status_code,200,changed.json)
        self.assertTrue(client.get('/api/questions/next?chapter=1&ability=50').json['question_text'].startswith('修改後'))
        invalid=deepcopy(changed.json['document']);invalid['steps'][0]['rules'][1]['explanation']=''
        self.assertEqual(client.put('/api/admin/specs/'+saved['spec_id'],json=invalid,headers=headers).status_code,400)
        self.assertEqual(client.get('/api/admin/specs/'+saved['spec_id']).json['revision'],changed.json['document']['revision'])
        self.assertEqual(client.post('/api/admin/specs',json=data,headers=headers).status_code,409)
        unpublish=changed.json['document'];unpublish['status']='draft'
        self.assertEqual(client.put('/api/admin/specs/'+saved['spec_id'],json=unpublish,headers=headers).status_code,200)
        self.assertEqual(client.get('/api/questions/next?chapter=1&ability=50').status_code,404)
        self.assertEqual(client.post('/api/admin/logout',headers=headers).status_code,200)
        self.assertEqual(client.get('/api/admin/catalog').status_code,401)

    def test_private_files_and_invalid_requests(self):
        client=app.test_client()
        for path in ['/static/.local/admin-auth.json','/static/database/backups/x.json','/static/backend/app.py','/static/啟動程式.bat']:
            self.assertEqual(client.get(path).status_code,404)
        response=client.get('/static/js/admin.js')
        self.assertEqual(response.status_code,200)
        response.close()
        self.assertEqual(client.get('/static/css/../.local/admin-auth.json').status_code,404)
        self.assertEqual(client.post('/api/admin/login',json=['bad']).status_code,400)
        for args in ['chapter=0&ability=50','chapter=1&ability=nan','chapter=1&ability=101','chapter=x&ability=50']:
            self.assertEqual(client.get('/api/questions/next?'+args).status_code,400)
        cross=client.post('/api/admin/login',json={'username':'admin','password':'test-password'},headers={'Origin':'https://example.com'})
        self.assertEqual(cross.status_code,403)


if __name__=='__main__': unittest.main(verbosity=2)
