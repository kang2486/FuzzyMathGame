"""Check all authored conceptual options without requiring a MySQL connection."""
from copy import deepcopy
from fractions import Fraction
from itertools import product
from pathlib import Path
import random
import sys
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'database'))
from concept_options import OPTIONS
from test_l02_generation import load_seed_spec
from dev_bank import generate_from_spec


class ConceptOptionsTests(unittest.TestCase):
    def test_every_builtin_step_has_three_explained_misconceptions(self):
        with patch('random.randint', side_effect=random.Random(42).randint):
            for type_id, authored in OPTIONS.items():
                for difficulty in range(1, 6):
                    spec = load_seed_spec(type_id, difficulty)
                    self.assertEqual(len(spec['steps']), len(authored))
                    for _ in range(100):
                        question = generate_from_spec(spec)
                        for step in question['steps']:
                            options = step['options']
                            self.assertEqual(len(options), 4)
                            self.assertEqual(sum(o['is_correct'] for o in options), 1)
                            self.assertEqual(len({o['text'] for o in options}), 4)
                            self.assertEqual(len({o['misconception_code'] for o in options}), 4)
                            for option in options:
                                self.assertNotIn('{{', option['text'])
                                self.assertNotIn('ARITHMETIC', option['misconception_code'])
                                self.assertEqual(option['is_correct'], option['misconception_code'] == 'CORRECT')
                                if not option['is_correct']:
                                    self.assertTrue(option['explanation'])

    def test_limit_factor_options_are_not_equivalent_even_when_coefficient_is_one(self):
        # Compare polynomial coefficients, including the a=1 / c=1 boundary.
        for a, c in product(range(1, 7), repeat=2):
            correct = (a, 0, -a*c*c)
            wrong = [(a, -2*a*c, a*c*c), (a, 2*a*c, a*c*c), (a, 0, a*c*c)]
            self.assertNotIn(correct, wrong)
            self.assertEqual(len(set(wrong)), 3)
        spec = load_seed_spec('L02', 1)
        codes = [rule['misconception_code'] for rule in spec['steps'][1]['rules']]
        self.assertNotIn('DID_NOT_CANCEL', codes)

    def test_same_coefficient_does_not_make_missing_C_correct(self):
        spec = load_seed_spec('I01', 3)
        question = generate_from_spec(spec)
        options = {o['misconception_code']: o for o in question['steps'][-1]['options']}
        self.assertTrue(options['CORRECT']['is_correct'])
        self.assertFalse(options['MISSING_INTEGRATION_CONSTANT']['is_correct'])
        self.assertIn('+C', options['CORRECT']['text'])

    def test_invalid_concept_options_fail_instead_of_using_numeric_fillers(self):
        original = load_seed_spec('F09', 1)
        for mutate in ('remove', 'duplicate', 'missing_explanation'):
            spec = deepcopy(original)
            rules = spec['steps'][0]['rules']
            if mutate == 'remove':
                rules.pop()
            elif mutate == 'duplicate':
                rules[1]['option_template'] = rules[0]['option_template']
            else:
                rules[1]['explanation'] = ''
            with self.assertRaises(ValueError):
                generate_from_spec(spec)


if __name__ == '__main__':
    unittest.main(verbosity=2)
