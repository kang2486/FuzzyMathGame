"""Exercise the new symbolic limit generator without requiring a running MySQL server."""
import csv
import json
from pathlib import Path
import re
import sys
import types
import unittest
from fractions import Fraction

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'backend'))

# dev_bank only needs mysql.connector when connect() is called. This test builds
# specs from the generated seed and exercises the real pure generation function.
mysql = types.ModuleType('mysql')
mysql.connector = types.SimpleNamespace(connect=lambda **kwargs: None)
sys.modules.setdefault('mysql', mysql)
sys.modules.setdefault('mysql.connector', mysql.connector)
from dev_bank import generate_from_spec  # noqa: E402


def sql_rows(table):
    rows = []
    pattern = re.compile(rf'^INSERT INTO {table}(?: \((.*?)\))? VALUES \((.*)\);$')
    for line in (ROOT / 'database' / 'seed.sql').read_text(encoding='utf-8').splitlines():
        match = pattern.match(line)
        if not match:
            continue
        values = next(csv.reader([match.group(2)], delimiter=',', quotechar="'",
                                 doublequote=True, escapechar='\\', skipinitialspace=True))
        rows.append((match.group(1), values))
    return rows


def load_seed_spec(type_id, difficulty):
    spec_id = f'{type_id}_DEV_D{difficulty}'
    spec = next(values for _, values in sql_rows('question_spec') if values[0] == spec_id)
    result = {
        'spec_id': spec[0], 'type_id': spec[1], 'difficulty': int(spec[2]),
        'question_template': spec[3], 'question_latex_template': spec[4],
        'derived_values': json.loads(spec[5]), 'answer_rule': spec[6],
    }
    result['parameters'] = [
        {'parameter_name': values[1], 'min_value': int(values[2]), 'max_value': int(values[3])}
        for _, values in sql_rows('spec_parameter') if values[0] == spec_id
    ]
    result['steps'] = []
    for _, values in sql_rows('solution_step'):
        if values[1] != spec_id:
            continue
        step = {
            'step_id': values[0], 'spec_id': values[1], 'step_order': int(values[2]),
            'display_template': values[3], 'value_rule': values[4], 'hint': values[5], 'rules': []
        }
        for columns, option in sql_rows('solution_option'):
            if option[0] != step['step_id']:
                continue
            step['rules'].append({
                'option_order': int(option[1]), 'value_rule': option[2],
                'misconception_code': option[3], 'explanation': option[4],
                'option_template': option[5] if len(option) > 5 else None,
            })
        result['steps'].append(step)
    return result


def load_l02_spec(difficulty):
    return load_seed_spec('L02', difficulty)


class L02GenerationTests(unittest.TestCase):
    def test_all_levels_have_valid_symbolic_steps_and_numeric_limit(self):
        for difficulty in range(1, 6):
            spec = load_l02_spec(difficulty)
            for _ in range(100):
                question = generate_from_spec(spec)
                params = {name: Fraction(value) for name, value in question['parameters'].items()}
                self.assertEqual(Fraction(question['answer_value']), 2 * params['a'] * params['c'])
                self.assertEqual(question['total_steps'], 3)
                self.assertIn(r'\lim', question['question_latex'])
                self.assertNotIn('{{', question['question_latex'])
                correct_factor = next(
                    option['text'] for option in question['steps'][0]['options'] if option['is_correct']
                )
                correct_cancel = next(
                    option['text'] for option in question['steps'][1]['options'] if option['is_correct']
                )
                self.assertIn(f"x-{params['c']}", correct_factor)
                self.assertIn(f"x+{params['c']}", correct_factor)
                self.assertIn(f"x+{params['c']}", correct_cancel)
                for step in question['steps']:
                    options = step['options']
                    self.assertEqual(len(options), 4)
                    self.assertEqual(sum(option['is_correct'] for option in options), 1)
                    self.assertEqual(len({option['text'] for option in options}), 4)


if __name__ == '__main__':
    unittest.main(verbosity=2)
