"""Regression checks for quoted semicolons in the bundled bank scripts."""
from pathlib import Path
import sys
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'database'))
from sql_statements import split_statements


class SqlStatementTests(unittest.TestCase):
    def test_quoted_semicolons_and_escaped_quotes(self):
        source = "SELECT 'a;b', 'it''s;c', 'it\\'s;d'; SELECT 2;"
        self.assertEqual(list(split_statements(source)), ["SELECT 'a;b', 'it''s;c', 'it\\'s;d'", 'SELECT 2'])

    def test_seed_version_description_stays_in_one_statement(self):
        statements = list(split_statements((ROOT / 'database/seed.sql').read_text(encoding='utf-8')))
        self.assertIn("INSERT INTO bank_meta VALUES (3,'Chapter 2 factor-and-cancel limit; symbolic choices')", statements)
        self.assertEqual(statements[-1], 'COMMIT')


if __name__ == '__main__':
    unittest.main()
