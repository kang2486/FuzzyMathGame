
@echo off
chcp 65001 >nul
cd /d "%USERPROFILE%\Desktop\FuzzyMathGame\backend"

start "" http://127.0.0.1:5000/
python app.py

pause