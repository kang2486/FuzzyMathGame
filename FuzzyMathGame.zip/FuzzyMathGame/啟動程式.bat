﻿@echo off
chcp 65001 >nul

cd /d "%~dp0"

REM 設定 MySQL 資料庫密碼
set "FUZZY_DB_PASSWORD=Auag74123"

REM 開啟遊戲網頁
REM launch_game.py opens the page after a compatible server is ready.

set "FUZZY_DATA_MODE=mysql_dev"

REM 啟動 Flask 後端
py -3 "%~dp0database\launch_game.py"

pause
